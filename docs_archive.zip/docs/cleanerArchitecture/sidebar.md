# cleanerArchitecture

- [Home](index.html)
- [Architecture](architecture.md)
- [About](about.html)

## About This Dashboard

This dashboard documents the clean, simple architecture of the SidebarDashboard project.

## Navigation

- [Project Architecture](architecture.md)
- [Welcome](welcome.md)
