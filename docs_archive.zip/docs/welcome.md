# Welcome to test_new_dashboard

This is your new dashboard. You can:

1. Edit this welcome page
2. Update the sidebar navigation
3. Add your own content files

## Getting Started

1. Add your content to the sidebar
2. Create new markdown files for your content
3. Test locally before publishing
